var ang = angular.module('ang', ['ngRoute'])
///////////////////////////////NG ROUTE/////////////////////////////////////////////////
ang.config(function ($routeProvider, $locationProvider) {
    $routeProvider
        .when('/login', {
            templateUrl: 'view/login.html',
            controller: "LoginCTRL"
        })
        .when('/produto', {
            templateUrl: 'view/produto.html',
            controller: "ProCTRL",
        })
        .when('/compradores', {
            templateUrl: 'view/compradores.html',
            controller: "CompCTRL"
        })
        .otherwise({
            redirectTo: '/login'
        });


})
/////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////CONTROLLER VIEW/////////////////////////////////////////////
ang.controller("LoginCTRL",
    function ($scope, $location) {
        $scope.click = function () {
            $location.path("/produto");
        };
    });

ang.controller("ProCTRL",
    function ($scope, $location) {
        $scope.click = function () {
            $location.path("/compradores");
        };

        $scope.logout = function () {
            $location.path("/login");
        };
    });

ang.controller("CompCTRL",
    function ($scope, $location ,$http) {
        var modal = document.getElementById('modal');
        $scope.dados = [];
        $scope.compradores = [];
        let payload = {
            token: "dQn4IM_RdXoR3ZvggZr14Q",
            data: {
                first_name: "nameFirst",
                last_name: "nameLast",
                data: "dateDOB",
                street: "addressStreetName",
                city: "addressCity",
                email: "internetEmail",
                mobile: "phoneMobile",
                _repeat: 5

            }

        };

        $http({
            method: 'POST',
            url: "https://app.fakejson.com/q",
            data: payload
        }).then(function sucessCallback(dt) {
            $scope.compradores =dt.data;
        });
        $scope.click = function () {
            $location.path("/produto");
        };

        $scope.logout = function () {
            $location.path("/login");
        };

        $scope.modal = function(dado){
            modal.style.display = "Block";
            $scope.dados = dado;
        };

        $scope.modal_close = function(){
            modal.style.display = "none";
            $scope.dados = [];
        };
    });

